package win.regin.chapter1;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * @author :Reginer in  2018/9/6 20:39.
 * 联系方式:QQ:282921012
 * 功能描述:新手教学
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mUsername;
    private EditText mPwd;
    private static final String REAL_USERNAME = "282921012";
    private static final String REAL_PWD = "123456";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mUsername = findViewById(R.id.etUsername);
        mPwd = findViewById(R.id.etPwd);
        findViewById(R.id.btnLogin).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        checkLogin();
    }

    private void checkLogin() {
        String username = mUsername.getText().toString();
        String pwd = mPwd.getText().toString();
        if (TextUtils.equals(REAL_USERNAME, username) && TextUtils.equals(REAL_PWD, pwd)) {
            Toast.makeText(this, R.string.login_success, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.login_failed, Toast.LENGTH_SHORT).show();
        }
    }
}
